.. _getting_started-requirements:

============
Requirements
============

* codecov==2.0.15
* coverage==4.5.2
* pandas==0.24.2
* pylint==2.3.0
* numpy==1.16.4
* xmlrunner==1.7.7
* numba==0.43.0
* scikit-learn==0.21