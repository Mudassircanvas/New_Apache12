.. _additional_information-contact:

=======
Contact
=======

We have recently opened access to our Slack channel_ to help form a community and encourage contributions.

Looking forward to hearing from you!

.. _channel: https://join.slack.com/t/mlfinlab/shared_invite/enQtOTUzNjAyNDI1NTc1LTU0NTczNWRlM2U5ZDZiZTUxNTgzNzBlNDU3YmY5MThkODdiMTgwNzI5NDQ2NWI0YTYyMmI3MjBkMzY2YjVkNzc